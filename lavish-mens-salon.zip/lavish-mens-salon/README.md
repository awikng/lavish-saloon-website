# Lavish Men's Salon - Modern React + TypeScript Web App

A complete modern front-end web application for **Lavish Men's Salon**, featuring facial treatments, haircuts, grooming services, and an interactive booking system.

## How to run this project in VS Code:

1. **Unzip** this downloaded file.
2. Open **VS Code**, go to `File` -> `Open Folder...`, and select the `lavish-mens-salon` folder.
3. Open the built-in VS Code Terminal (`Ctrl + ~` or `Cmd + ~`).
4. Run:
   ```bash
   npm install
   ```
5. Start the development server:
   ```bash
   npm run dev
   ```
6. Open the link provided in the terminal (usually `http://localhost:5173`) in your browser.
