import React, { useState } from 'react';
import { Sparkles, Calendar, Clock, CheckCircle2, Phone, MapPin, Award, Scissors, UserCheck, ShieldCheck } from 'lucide-react';

interface Service {
  id: number;
  name: string;
  category: 'Facial' | 'Hair' | 'Grooming' | 'VIP Package';
  price: number;
  duration: string;
  description: string;
  featured?: boolean;
}

export default function App() {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedService, setSelectedService] = useState<string>('');
  const [clientName, setClientName] = useState<string>('');
  const [clientPhone, setClientPhone] = useState<string>('');
  const [preferredDate, setPreferredDate] = useState<string>('');
  const [preferredTime, setPreferredTime] = useState<string>('');
  const [isSubmitted, setIsSubmitted] = useState<boolean>(false);

  const services: Service[] = [
    {
      id: 1,
      name: "Lavish Signature Deep Cleanse Facial",
      category: "Facial",
      price: 65,
      duration: "45 mins",
      description: "Customized deep cleansing, steaming, ultrasonic blackhead extraction, and hydra-boosting gel mask tailored specifically for men's thicker skin tone.",
      featured: true
    },
    {
      id: 2,
      name: "24K Gold Rejuvenating Facial",
      category: "Facial",
      price: 90,
      duration: "60 mins",
      description: "Anti-aging luxury treatment with 24K gold foil infusion, peptide therapy, and lymphatic face massage to reverse fatigue and reduce dark circles.",
      featured: true
    },
    {
      id: 3,
      name: "Activated Charcoal Detox Treatment",
      category: "Facial",
      price: 55,
      duration: "40 mins",
      description: "Pore-tightening charcoal mask, exfoliation, and sebum control serum to eliminate excess oils and razor bump irritation.",
    },
    {
      id: 4,
      name: "Executive Precision Haircut",
      category: "Hair",
      price: 45,
      duration: "35 mins",
      description: "Consultation, custom tailored fade/cut, peppermint shampoo scalp wash, and premium matte clay styling.",
    },
    {
      id: 5,
      name: "Hot Towel Beard Sculpture & Spa",
      category: "Grooming",
      price: 40,
      duration: "30 mins",
      description: "Straight razor outline, essential oil hot towel treatment, beard trimming, and deep conditioning beard oil massage.",
    },
    {
      id: 6,
      name: "The Lavish VIP Presidential Package",
      category: "VIP Package",
      price: 150,
      duration: "105 mins",
      description: "Full Signature Facial + Executive Haircut + Hot Towel Beard Spa + Scalp & Shoulder Stress Relief Massage.",
      featured: true
    }
  ];

  const categories = ['All', 'Facial', 'Hair', 'Grooming', 'VIP Package'];

  const filteredServices = selectedCategory === 'All'
    ? services
    : services.filter(s => s.category === selectedCategory);

  const handleBooking = (e: React.FormEvent) => {
    e.preventDefault();
    if (!clientName || !clientPhone) return;
    setIsSubmitted(true);
  };

  return (
    <div style={{ minHeight: '100vh', backgroundColor: '#0d0f12', color: '#e2e8f0' }}>
      
      {/* Top Banner / Announcement */}
      <div style={{ backgroundColor: '#c59b27', color: '#000', textAlign: 'center', padding: '8px 16px', fontSize: '14px', fontWeight: '600', letterSpacing: '0.5px' }}>
        <Sparkles style={{ width: '16px', height: '16px', display: 'inline', verticalAlign: 'middle', marginRight: '6px' }} />
        First Time Guest Special: Get 15% OFF Any Facial Treatment This Week!
      </div>

      {/* Header Navigation */}
      <header style={{ borderBottom: '1px solid #1e293b', padding: '20px 32px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#11151c', sticky: 'top', top: 0, zIndex: 50 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <div style={{ width: '40px', height: '40px', borderRadius: '8px', backgroundColor: '#c59b27', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#0d0f12', fontWeight: '900', fontSize: '20px' }}>
            L
          </div>
          <div>
            <h1 style={{ fontSize: '20px', fontWeight: '800', letterSpacing: '1.5px', color: '#f8fafc', margin: 0 }}>LAVISH</h1>
            <p style={{ fontSize: '10px', color: '#c59b27', letterSpacing: '2px', textTransform: 'uppercase', margin: 0 }}>Men's Grooming & Facial Lounge</p>
          </div>
        </div>

        <nav style={{ display: 'flex', gap: '28px', alignItems: 'center' }}>
          <a href="#about" style={{ color: '#94a3b8', textDecoration: 'none', fontSize: '14px', fontWeight: '500' }}>About</a>
          <a href="#services" style={{ color: '#94a3b8', textDecoration: 'none', fontSize: '14px', fontWeight: '500' }}>Services & Pricing</a>
          <a href="#booking" style={{ backgroundColor: '#c59b27', color: '#0d0f12', padding: '10px 20px', borderRadius: '6px', fontWeight: '700', textDecoration: 'none', fontSize: '14px' }}>Book Appointment</a>
        </nav>
      </header>

      {/* Hero Section */}
      <section style={{ padding: '80px 24px', textAlign: 'center', background: 'radial-gradient(circle at 50% 20%, #1e2638 0%, #0d0f12 70%)', borderBottom: '1px solid #1e293b' }}>
        <div style={{ maxWidth: '800px', margin: '0 auto' }}>
          <span style={{ display: 'inline-block', backgroundColor: '#1e293b', color: '#c59b27', border: '1px solid #334155', padding: '6px 16px', borderRadius: '20px', fontSize: '13px', fontWeight: '600', marginBottom: '20px' }}>
            ★ Premier Skincare & Grooming Sanctuary
          </span>
          <h2 style={{ fontSize: '48px', fontWeight: '800', lineHeight: '1.15', color: '#ffffff', marginBottom: '20px' }}>
            Refine Your Look.<br />
            <span style={{ color: '#c59b27' }}>Rejuvenate Your Skin.</span>
          </h2>
          <p style={{ fontSize: '18px', color: '#94a3b8', marginBottom: '36px', lineHeight: '1.7' }}>
            Experience specialized facial treatments, precision haircuts, and hot towel beard styling crafted exclusively for the modern gentleman.
          </p>
          
          <div style={{ display: 'flex', justifyContent: 'center', gap: '16px', flexWrap: 'wrap' }}>
            <a href="#booking" style={{ backgroundColor: '#c59b27', color: '#0d0f12', padding: '14px 32px', borderRadius: '8px', fontWeight: '800', fontSize: '16px', textDecoration: 'none' }}>
              Book Your Session
            </a>
            <a href="#services" style={{ backgroundColor: '#1e293b', color: '#f8fafc', border: '1px solid #334155', padding: '14px 28px', borderRadius: '8px', fontWeight: '600', fontSize: '16px', textDecoration: 'none' }}>
              Explore Treatments
            </a>
          </div>

          {/* Quick Stats */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '20px', marginTop: '60px', padding: '24px', backgroundColor: '#11151c', borderRadius: '12px', border: '1px solid #1e293b' }}>
            <div>
              <Award style={{ color: '#c59b27', marginBottom: '8px' }} />
              <h4 style={{ fontSize: '20px', color: '#fff' }}>5,000+</h4>
              <p style={{ fontSize: '12px', color: '#64748b' }}>Satisfied Clients</p>
            </div>
            <div>
              <UserCheck style={{ color: '#c59b27', marginBottom: '8px' }} />
              <h4 style={{ fontSize: '20px', color: '#fff' }}>Certified</h4>
              <p style={{ fontSize: '12px', color: '#64748b' }}>Male Estheticians</p>
            </div>
            <div>
              <ShieldCheck style={{ color: '#c59b27', marginBottom: '8px' }} />
              <h4 style={{ fontSize: '20px', color: '#fff' }}>100% Organic</h4>
              <p style={{ fontSize: '12px', color: '#64748b' }}>Skincare Formulas</p>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" style={{ padding: '80px 24px', maxWidth: '1200px', margin: '0 auto' }}>
        <div style={{ textAlign: 'center', marginBottom: '40px' }}>
          <h3 style={{ fontSize: '32px', fontWeight: '800', color: '#fff', marginBottom: '10px' }}>Our Specialty Menu</h3>
          <p style={{ color: '#94a3b8' }}>Select a category to view specialized treatments designed for men</p>
          
          {/* Category Filter Tabs */}
          <div style={{ display: 'flex', justifyContent: 'center', gap: '10px', marginTop: '24px', flexWrap: 'wrap' }}>
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                style={{
                  backgroundColor: selectedCategory === cat ? '#c59b27' : '#1e293b',
                  color: selectedCategory === cat ? '#0d0f12' : '#94a3b8',
                  border: 'none',
                  padding: '10px 20px',
                  borderRadius: '30px',
                  fontWeight: '700',
                  cursor: 'pointer',
                  fontSize: '14px',
                  transition: 'all 0.2s'
                }}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Services Cards */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '24px' }}>
          {filteredServices.map((service) => (
            <div 
              key={service.id} 
              style={{ 
                backgroundColor: '#11151c', 
                borderRadius: '12px', 
                padding: '28px', 
                border: service.featured ? '2px solid #c59b27' : '1px solid #1e293b',
                position: 'relative',
                display: 'flex',
                flexDirection: 'column',
                justify: 'space-between'
              }}
            >
              {service.featured && (
                <span style={{ position: 'absolute', top: '-12px', right: '20px', backgroundColor: '#c59b27', color: '#000', fontSize: '11px', fontWeight: '800', padding: '2px 10px', borderRadius: '10px', textTransform: 'uppercase' }}>
                  Most Popular
                </span>
              )}
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '12px' }}>
                  <h4 style={{ fontSize: '20px', fontWeight: '700', color: '#fff', margin: 0 }}>{service.name}</h4>
                  <span style={{ fontSize: '22px', fontWeight: '800', color: '#c59b27', marginLeft: '12px' }}>${service.price}</span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: '#64748b', fontSize: '13px', marginBottom: '16px' }}>
                  <Clock style={{ width: '14px', height: '14px' }} />
                  <span>{service.duration}</span>
                </div>
                <p style={{ color: '#94a3b8', fontSize: '14px', lineHeight: '1.6', marginBottom: '24px' }}>
                  {service.description}
                </p>
              </div>

              <button
                onClick={() => {
                  setSelectedService(service.name);
                  window.location.hash = '#booking';
                }}
                style={{
                  width: '100%',
                  backgroundColor: selectedService === service.name ? '#22c55e' : 'transparent',
                  color: selectedService === service.name ? '#fff' : '#c59b27',
                  border: selectedService === service.name ? '1px solid #22c55e' : '1px solid #c59b27',
                  padding: '12px',
                  borderRadius: '6px',
                  fontWeight: '700',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '8px'
                }}
              >
                {selectedService === service.name ? (
                  <>
                    <CheckCircle2 style={{ width: '16px', height: '16px' }} /> Selected for Booking
                  </>
                ) : (
                  'Select Treatment'
                )}
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* Booking Form Section */}
      <section id="booking" style={{ backgroundColor: '#11151c', padding: '80px 24px', borderTop: '1px solid #1e293b' }}>
        <div style={{ maxWidth: '600px', margin: '0 auto', backgroundColor: '#0d0f12', padding: '40px', borderRadius: '16px', border: '1px solid #1e293b' }}>
          <div style={{ textAlign: 'center', marginBottom: '32px' }}>
            <Calendar style={{ width: '36px', height: '36px', color: '#c59b27', marginBottom: '12px' }} />
            <h3 style={{ fontSize: '28px', fontWeight: '800', color: '#fff' }}>Reserve Your Appointment</h3>
            <p style={{ color: '#94a3b8', fontSize: '14px' }}>Fill in your details below and our team will confirm your slot</p>
          </div>

          {isSubmitted ? (
            <div style={{ textAlign: 'center', padding: '40px 20px', backgroundColor: '#14271d', borderRadius: '12px', border: '1px solid #22c55e' }}>
              <CheckCircle2 style={{ width: '56px', height: '56px', color: '#22c55e', margin: '0 auto 16px auto' }} />
              <h4 style={{ fontSize: '22px', color: '#fff', marginBottom: '8px' }}>Booking Request Received!</h4>
              <p style={{ color: '#cbd5e1', fontSize: '15px', marginBottom: '16px' }}>
                Thank you <strong>{clientName}</strong>. We have reserved your request for <strong>{selectedService || 'your service'}</strong> on <strong>{preferredDate || 'your date'}</strong> at <strong>{preferredTime || 'your time'}</strong>.
              </p>
              <p style={{ color: '#94a3b8', fontSize: '13px' }}>Our lounge concierge will call you at {clientPhone} to confirm.</p>
              <button 
                onClick={() => setIsSubmitted(false)}
                style={{ marginTop: '24px', backgroundColor: '#c59b27', color: '#0d0f12', border: 'none', padding: '10px 20px', borderRadius: '6px', fontWeight: '700', cursor: 'pointer' }}
              >
                Book Another Service
              </button>
            </div>
          ) : (
            <form onSubmit={handleBooking} style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
              <div>
                <label style={{ display: 'block', fontSize: '13px', fontWeight: '600', color: '#cbd5e1', marginBottom: '6px' }}>
                  Full Name *
                </label>
                <input
                  required
                  type="text"
                  placeholder="e.g. Alex Mercer"
                  value={clientName}
                  onChange={(e) => setClientName(e.target.value)}
                  style={{ width: '100%', padding: '12px 16px', borderRadius: '8px', border: '1px solid #334155', backgroundColor: '#1e293b', color: '#fff', fontSize: '15px' }}
                />
              </div>

              <div>
                <label style={{ display: 'block', fontSize: '13px', fontWeight: '600', color: '#cbd5e1', marginBottom: '6px' }}>
                  Phone Number *
                </label>
                <input
                  required
                  type="tel"
                  placeholder="+1 (555) 000-0000"
                  value={clientPhone}
                  onChange={(e) => setClientPhone(e.target.value)}
                  style={{ width: '100%', padding: '12px 16px', borderRadius: '8px', border: '1px solid #334155', backgroundColor: '#1e293b', color: '#fff', fontSize: '15px' }}
                />
              </div>

              <div>
                <label style={{ display: 'block', fontSize: '13px', fontWeight: '600', color: '#cbd5e1', marginBottom: '6px' }}>
                  Select Treatment Service
                </label>
                <select
                  value={selectedService}
                  onChange={(e) => setSelectedService(e.target.value)}
                  style={{ width: '100%', padding: '12px 16px', borderRadius: '8px', border: '1px solid #334155', backgroundColor: '#1e293b', color: '#fff', fontSize: '15px' }}
                >
                  <option value="">-- Choose a facial or grooming service --</option>
                  {services.map((s) => (
                    <option key={s.id} value={s.name}>
                      {s.name} (${s.price})
                    </option>
                  ))}
                </select>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
                <div>
                  <label style={{ display: 'block', fontSize: '13px', fontWeight: '600', color: '#cbd5e1', marginBottom: '6px' }}>
                    Preferred Date
                  </label>
                  <input
                    type="date"
                    value={preferredDate}
                    onChange={(e) => setPreferredDate(e.target.value)}
                    style={{ width: '100%', padding: '12px 16px', borderRadius: '8px', border: '1px solid #334155', backgroundColor: '#1e293b', color: '#fff', fontSize: '14px' }}
                  />
                </div>
                <div>
                  <label style={{ display: 'block', fontSize: '13px', fontWeight: '600', color: '#cbd5e1', marginBottom: '6px' }}>
                    Preferred Time
                  </label>
                  <input
                    type="time"
                    value={preferredTime}
                    onChange={(e) => setPreferredTime(e.target.value)}
                    style={{ width: '100%', padding: '12px 16px', borderRadius: '8px', border: '1px solid #334155', backgroundColor: '#1e293b', color: '#fff', fontSize: '14px' }}
                  />
                </div>
              </div>

              <button
                type="submit"
                style={{
                  backgroundColor: '#c59b27',
                  color: '#0d0f12',
                  padding: '16px',
                  borderRadius: '8px',
                  fontWeight: '800',
                  fontSize: '16px',
                  border: 'none',
                  cursor: 'pointer',
                  marginTop: '10px'
                }}
              >
                Confirm Appointment Request
              </button>
            </form>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer style={{ borderTop: '1px solid #1e293b', padding: '40px 24px', backgroundColor: '#090b0e', color: '#64748b', textAlign: 'center', fontSize: '14px' }}>
        <p style={{ color: '#f8fafc', fontWeight: '700', marginBottom: '8px' }}>LAVISH MEN'S SALON & FACIAL LOUNGE</p>
        <p style={{ marginBottom: '16px' }}>Premium grooming, executive haircuts, and specialized facial treatments for men.</p>
        <p>© 2026 Lavish Men's Salon. Built with React & TypeScript.</p>
      </footer>

    </div>
  );
}
